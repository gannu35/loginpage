package com.project.Registertation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String url="jdbc:mysql://localhost:3306/logindetails?useSSL=false";
	String un="root";
	String pwd="gannu@35";
	Connection con=null;
	PreparedStatement psmt=null;
	RequestDispatcher rd=null;
	
	
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String uname=request.getParameter("name");
		String uemail=request.getParameter("email");
		String upswd=request.getParameter("pass");
		String umobile=request.getParameter("contact");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url,un,pwd);
			String query="insert into users(uname,upswd,uemail,umobile) values(?,?,?,?)";
			psmt = con.prepareStatement(query);
			
			psmt.setString(1,uname);
			psmt.setString(2,upswd);
			psmt.setString(3,uemail);
			psmt.setString(4,umobile);
			
			int i = psmt.executeUpdate();
			rd = request.getRequestDispatcher("registration.jsp");
			
			if(i>0)
			{
				request.setAttribute("status","success");
				
			}
			else
			{
				request.setAttribute("status","success");
				
			}
			rd.forward(request, response);
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			try
			{
				
				psmt.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				
			}
			
		}
	
	}
	

}
