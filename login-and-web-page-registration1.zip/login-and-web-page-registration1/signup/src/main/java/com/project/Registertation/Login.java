package com.project.Registertation;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String url="jdbc:mysql://localhost:3306/logindetails?useSSL=false";
	String un="root";
	String pwd="gannu@35";
	Connection con=null;
	PreparedStatement psmt=null;
	RequestDispatcher rd=null;
	HttpSession session=null;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String uemail=request.getParameter("email");
		String upswd=request.getParameter("pass");
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url,un,pwd);
			String query="select * from users where uemail=? and upswd=?";
			psmt = con.prepareStatement(query);
			
			psmt.setString(1,uemail);
			psmt.setString(2,upswd);
			
			ResultSet res= psmt.executeQuery();
			
			if(res.next())
			{
				session.setAttribute("name",res.getString("uname"));
				rd= request.getRequestDispatcher("index.jsp");
				
			}
			else
			{
				request.setAttribute("status", "failed");
				rd=request.getRequestDispatcher("login.jsp");
				
			}
			rd.forward(request, response);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
